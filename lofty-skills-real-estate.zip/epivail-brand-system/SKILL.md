---
name: epivail-brand-system
description: Master brand identity and design system for Charles Harrison / EpiVail / Epique Realty Colorado Mountain Region. Use this skill whenever creating ANY content, artifact, page, document, graphic, video component, social post, or written material for the EpiVail brand — even if Charles doesn't explicitly say "brand guidelines." Always activate for EpiVail pages, agent attraction materials, TikTok/Reel scripts, LinkedIn content, Remotion components, HTML artifacts, PDF documents, or anything carrying the EpiVail, Epique Realty Colorado Mountain Region, or Charles Harrison professional identity. This skill is the single source of truth for colors, typography, voice, tone, positioning, and the Luxury Resimercial™ concept.
---

# EpiVail Brand System
**Owner**: Charles Harrison | Professional brand handle: EpiVail  
**Brokerage brand**: Epique Realty Colorado Mountain Region  
**Territory**: Vail / Beaver Creek luxury resort corridor, Eagle County, Colorado  
**Tagline**: *"Southern Hospitality Meets Mountain Mastery"*  
**Proprietary concept**: Luxury Resimercial™ — the intersection of luxury residential, short-term rental investment, and boutique commercial real estate in mountain resort corridors

---

## Identity Rules

- Professional name in ALL materials: **Charles Harrison** — never "Chuck"
- Brand handle / short identity: **EpiVail**
- Full team brand: **Epique Realty Colorado Mountain Region**
- AI tool brand: **EpiVail Intelligence** (for analytics/data tools)
- TikTok: @epivail | Facebook: @CharlesHarrisonVail
- Real estate persona and healthcare (New Beginnings Mental Health) must remain **strictly separate** — never blend them

---

## Color System

```
Navy (Primary Background):   #0a1628  --navy
Navy Mid (Cards/Surfaces):   #0f1f3d  --navy-mid
Navy Light (Elevated):       #172847  --navy-light
Gold (Primary Accent):       #c9a84c  --gold
Gold Bright (Hover/Active):  #e8c66a  --gold-bright
Gold Dim (Secondary/Muted):  #8a6f2e  --gold-dim
Cream (Body Text on Dark):   #f5f0e8  --cream
White (Headlines):           #ffffff
Muted Text:                  #7a8ba8  --text-muted
Border (Subtle):             rgba(201,168,76,0.2)
```

**Usage rules:**
- Dark navy backgrounds are the default — this is a dark luxury aesthetic
- Gold is the signature accent: use for headlines, CTAs, borders, highlights
- Never use purple gradients, teal, or bright/neon colors
- Avoid white backgrounds — off-white (#f5f0e8) only in print/document contexts

---

## Typography

| Role | Font | Weight |
|---|---|---|
| Display / Headlines | Cormorant Garamond | 300–400 (italic for elegance) |
| UI / Body / Labels | DM Sans | 300–500 |
| Eyebrows / Stamps / Badges | Bebas Neue | Regular (letter-spaced) |
| Secondary Body (alt) | Montserrat | 300–400 |

**Rules:**
- Cormorant Garamond at large sizes = luxury signal. Use for hero text, section titles
- Bebas Neue in ALL CAPS with `letter-spacing: 0.2em+` for category labels and eyebrows
- DM Sans for all functional UI text, body copy, descriptions
- Never use Inter, Roboto, Arial, or system fonts in branded outputs
- Google Fonts CDN: `https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,300;1,400&family=DM+Sans:wght@300;400;500&family=Bebas+Neue&display=swap`

---

## Voice & Tone

**Core personality:**
- Warm but authoritative — Southern Hospitality with mountain credibility
- 25+ years of production experience in the Vail Valley — never talk down, always peer-to-peer
- Optimistic and confident, never boastful
- Relationship-first — every message should feel like it comes from a trusted advisor, not a salesperson

**Writing rules:**
- Use "we" when speaking as Epique Realty Colorado Mountain Region; "I" when Charles is speaking personally
- Avoid corporate jargon and buzzword soup
- Short, punchy sentences for social. Longer, measured prose for luxury listing copy
- Warm closings: "Let's connect," "Happy to talk anytime," "Southern Hospitality, Mountain Results"
- Always sign off real estate materials: **Charles Harrison, Epique Area/Growth Leader**

**Tone by channel:**
| Channel | Tone |
|---|---|
| TikTok / Reels | Energetic, direct, hook-first, punchy |
| LinkedIn | Thought leader, measured, data-backed, professional warmth |
| Email (agent recruitment) | Personal, warm, peer-to-peer, no pressure |
| Listing copy | Luxurious, evocative, aspirational — sell the lifestyle |
| Website / pages | Authoritative, clean, let design do the heavy lifting |

---

## Luxury Resimercial™ Positioning

This is Charles's proprietary market concept — always frame it as unique and owned:

> *Luxury Resimercial™ is the convergence of luxury residential, short-term rental investment, and boutique commercial real estate — exclusive to mountain resort corridors like Vail and Beaver Creek.*

**The three pillars:**
1. **Luxury Residential** — primary and second-home mountain properties
2. **Short-Term Rental (STR) Investment** — ski-in/ski-out income-producing assets
3. **Boutique Commercial** — resort corridor retail, hospitality-adjacent commercial

When writing for investor clients or agent recruits, always position Charles as the *only* agent in the market who operates across all three pillars simultaneously.

---

## Visual Design Patterns

For HTML artifacts, pages, and Remotion components:

```css
/* Standard card pattern */
background: var(--navy-mid);
border: 1px solid rgba(201,168,76,0.2);
/* Hover accent line */
border-top: 2px solid linear-gradient(90deg, #8a6f2e, transparent);

/* Section eyebrow pattern */
font-family: 'Bebas Neue'; letter-spacing: 0.2em; color: #c9a84c;

/* Hero headline pattern */
font-family: 'Cormorant Garamond'; font-weight: 300; color: #ffffff;
/* with italic gold accent word */
em { color: #c9a84c; font-style: italic; }

/* Background depth */
background: radial-gradient(ellipse 80% 60% at 10% 10%, rgba(201,168,76,0.06), transparent 60%);
```

**Animation style:** Subtle, elegant. `fadeUp` (opacity + translateY) on load. Hover: `translateY(-3px)` with border-color transition. No flashy or bouncy animations — understated luxury.

---

## Key Market Context

- **Primary market**: Eagle County, CO — Vail, Beaver Creek, Avon, Eagle
- **Zip codes tracked**: 81657 (Vail), 81620 (Avon/Beaver Creek), 81631 (Eagle), 81632 (Edwards)
- **Price tiers**: Platinum $2.5M+, Gold $1M–$2.5M, Silver $500K–$1M, Bronze <$500K
- **International buyer markets**: France, Germany, Mexico (agent recruitment focus)
- **Key employer partners (EAP/Mountain Strong)**: Vail Health, Eagle County Government, Eagle County Schools, Antlers at Vail, Sonnenalp, Town of Avon

---

## Reference Files

- `references/social-templates.md` — TikTok/Reel scripts, LinkedIn post structures, caption formulas
- `references/listing-copy.md` — Luxury property description templates by property type
- `references/brand-assets.md` — Logo usage notes, QR code guidance, visual asset inventory
