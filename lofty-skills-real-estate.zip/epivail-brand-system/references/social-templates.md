# EpiVail Social Content Templates

## TikTok / Reel Script Formula

```
[HOOK — 0–3 sec] Bold statement, question, or visual pattern interrupt
[VALUE — 3–25 sec] The intel, tip, or story. Specific. Mountain context.
[CTA — 25–30 sec] One clear action. Follow, comment, DM, link in bio.
```

**Hook bank:**
- "Nobody's talking about what's happening in Vail right now..."
- "If you're a real estate agent in Colorado and you're not doing this..."
- "The ski-in/ski-out market just shifted. Here's what it means for you."
- "I've been selling luxury mountain real estate for 25 years. Here's what I see coming."
- "Luxury Resimercial™ — three words that changed how I build wealth in the mountains."

**Closing CTAs:**
- "Follow @epivail for daily Vail Valley intel."
- "DM me 'MOUNTAIN' and I'll send you the full breakdown."
- "Link in bio — book a call, let's talk strategy."

---

## LinkedIn Post Structure (6 Pillars)

### Pillar 1: Thought Leadership
```
[Bold opening line — statement or question]

[2–3 short paragraphs of insight]

[Takeaway line]

#VailValley #LuxuryRealEstate #LuxuryResimercial #EpiVail #MountainMarket
```

### Pillar 2: Market Intel
```
[Stat or data point as opener]

[Context — what it means for buyers/sellers/investors]

[Charles's read on the trend]

[CTA — "What are you seeing in your market? Drop it below."]
```

### Pillar 3: Agent Recruitment
```
[Pain point agents feel at other brokerages]

[What Epique does differently — lead with one specific benefit]

[The EpiVail / Epique Realty Colorado Mountain Region story]

[Soft CTA — "Curious what your business could look like here? Let's talk."]
```

### Pillar 4: Mountain Lifestyle
```
[Personal moment — ski day, mountain photo, trail, golf]

[Tie to professional insight — why living here makes you a better advisor]

[Authentic close — Southern Hospitality meets Mountain Mastery]
```

### Pillar 5: Engagement / Poll
```
[Simple, provocative question relevant to agents or buyers]
[2–4 poll options]
[Follow-up comment engaging with responses]
```

### Pillar 6: AI & Innovation
```
[What EpiVail Intelligence or AI tooling just did for a client or agent]
[The specific workflow or result]
[Tie to broader point about AI in luxury real estate]
[#EpiVailIntelligence #AIRealEstate #EpiqueAI]
```
