---
name: epique-agent-recruitment
description: Guides Charles Harrison (EpiVail, powered by EpiqueAI — Area/Growth Leader, Epique Realty Colorado Mountain Region) through national and international agent recruitment for Epique Realty. Use this skill whenever Charles mentions recruiting agents, prospecting real estate agents, reaching out to agents in the US, France, Germany, or Mexico, writing outreach scripts, building recruitment pipelines, or preparing for agent attraction conversations. Always activate for any Epique Realty Colorado Mountain Region, EpiVail, EpiqueAI, agent outreach, or recruitment-related task — even if Charles doesn't use the word "recruitment" explicitly.
---

# Epique Agent Recruitment Skill
**Identity**: Charles Harrison | EpiVail, powered by EpiqueAI | Area/Growth Leader – Epique Realty Colorado Mountain Region  
**Brand Tagline**: "Scale Smarter, Build Better, EpiVail"  
**Scope**: National and international agent recruitment  
**Tone**: Warm + professional — relationship-first, never transactional

---

## Core Value Proposition (Always Lead With These)
- **100% commission** after cap
- **Free healthcare** (included benefit)
- **Lofty CRM** (included, no extra cost)
- **12+ AI tools** (built-in suite)
- **Revenue share** program
- **Stock options** (NASDAQ: REAX)
- **EpiqueAI** — proprietary AI-powered tools and workflows
- **Epique Realty Colorado Mountain Region** — Colorado's premier mountain resort real estate team

---

## Workflow: Initial Outreach & Prospecting

### Step 1 — Identify Agent Profile
Before writing any outreach, ask Charles (or infer from context):
- **Market**: US (Colorado), France, Germany, or Mexico?
- **Agent type**: Luxury/resort specialist, generalist, commercial, new agent?
- **Channel**: Email, LinkedIn, WhatsApp, in-person, phone?
- **Language**: English, French, German, or Spanish?

### Step 2 — Select Market Script Template
Load the appropriate reference file based on market:
- US (Colorado): `references/us-colorado.md`
- France: `references/france.md`
- Germany: `references/germany.md`
- Mexico: `references/mexico.md`

### Step 3 — Personalize the Outreach
Customize the template with:
- Agent's name and brokerage (if known)
- Specific local market context
- Relevant Epique benefit most likely to resonate in that culture
- Charles's personal touch — always sign off as **Charles Harrison | EpiVail**

### Step 4 — Review & Deliver
Present the finished outreach to Charles for review. Offer to:
- Adjust tone (more formal / more casual)
- Translate if needed
- Create a follow-up sequence variant

---

## Cultural Intelligence by Market

### 🇺🇸 United States (Colorado Mountain Region)
- Lead with **freedom & income** — 100% commission resonates immediately
- Mention Vail Valley roots and 25+ years luxury market credibility
- Reference ski-in/ski-out, STR investment, Luxury Resimercial™ niche
- Casual-warm tone is appropriate; use first names immediately

### 🇫🇷 France
- **Formal first** — use "Monsieur/Madame" in initial contact
- French agents value **prestige and brand reputation** — lead with the luxury mountain corridor story
- Mention international market access and US second-home buyer pipeline
- Avoid aggressive income pitches early; establish relationship credibility first
- Consider opening in French, transitioning to English if response indicates comfort

### 🇩🇪 Germany
- **Precision and trust** are paramount — Germans respond to data and structure
- Lead with **stability, compliance, and clear commission structure**
- Highlight Epique's NASDAQ listing (REAX) as a credibility signal
- Formal tone required; use titles if known (Dr., etc.)
- Be direct and specific — avoid vague promises

### 🇲🇽 Mexico
- **Warm and relationship-driven** — family and community matter
- Luxury resort market alignment (Los Cabos, Riviera Maya) parallels Vail Valley
- Bilingual outreach preferred (Spanish opening, English available)
- Revenue share and stock options are strong motivators
- Reference Charles's luxury mountain resort expertise as aspirational parallel

---

## Key Trigger Phrases to Watch For
Activate this skill when Charles says any of the following:
- "Write me an outreach to an agent..."
- "I'm heading to France/Germany/Mexico..."
- "Help me recruit..."
- "Script for approaching an agent..."
- "Epique Realty Colorado Mountain Region pitch..."
- "Agent attraction..."
- "I want to talk to agents at [brokerage]..."

---

## Output Formats Available
- **Cold email** (formal/semi-formal)
- **LinkedIn DM** (concise, professional)
- **WhatsApp/text** (brief, warm)
- **In-person talking points** (bullet format for Charles to internalize)
- **Follow-up message** (after no response, 5–7 days)

---

## Reference Files
See `references/` folder for market-specific templates:
- `us-colorado.md` — Domestic Colorado mountain region scripts
- `france.md` — French market outreach scripts & cultural notes
- `germany.md` — German market outreach scripts & cultural notes
- `mexico.md` — Mexican market outreach scripts & cultural notes
