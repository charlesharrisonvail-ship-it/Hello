# France — Outreach Templates & Cultural Notes

## Cultural Reminders
- Open formally: "Monsieur / Madame [Last Name]"
- Establish credibility and relationship BEFORE discussing income
- French agents value prestige, heritage, and market reputation
- Reference the US luxury mountain second-home buyer pipeline as aspirational
- Transition to English naturally only after rapport is established

---

## Cold Email — French Agent (English with French Opening)
**Subject**: Une opportunité dans l'immobilier de luxe de montagne — Colorado

Monsieur / Madame [Last Name],

Je me permets de vous contacter en raison de votre expertise reconnue dans l'immobilier de prestige. *(I am reaching out in light of your recognized expertise in prestige real estate.)*

I am Charles Harrison, Area Leader for Epique Realty International in Colorado's Mountain Region — home to Vail, Beaver Creek, and some of North America's most coveted luxury resort properties. With 25+ years serving ultra-high-net-worth buyers in this corridor, I understand the standards your clientele expects.

I am expanding Epique Realty Colorado Mountain Region to include international partners who can serve European buyers seeking US mountain resort second homes — and connect US buyers with premier French properties.

Epique Realty offers an exceptional platform: full commission retention after cap, included healthcare, advanced CRM technology, and equity participation through our NASDAQ-listed parent company.

I will be in France later this year and would be honored to meet at your convenience.

Avec mes cordiales salutations,
Charles Harrison | EpiVail
Area Leader – Epique Colorado Mountain Region

---

## LinkedIn DM — French Agent
Bonjour [First Name], I'm Charles Harrison, Area Leader at Epique Realty in Colorado's Vail Valley. I'm developing international partnerships for Epique Realty Colorado Mountain Region and your expertise in [their market] caught my attention. I'll be visiting France this year and would welcome the opportunity to connect. Would you be open to a brief introduction? — Charles Harrison

---

## In-Person Talking Points (France Visit)
1. Open in French — even a few sentences demonstrates respect
2. Reference their specific market with genuine knowledge
3. Lead with the **bilateral opportunity** — French buyers in Colorado, US buyers in France
4. Introduce Epique as a modern, agent-first brokerage with NASDAQ credibility
5. Position Luxury Resimercial™ as a concept they can bring to their own market
6. Do NOT rush to commission talk — let that emerge naturally
7. Exchange business cards formally; follow up within 24 hours

---

## Follow-Up (Post-Meeting or No Response)
Subject: Suite à notre échange — Epique Realty Colorado

Monsieur / Madame [Last Name],

It was a genuine pleasure connecting with you [in person / via message]. I wanted to follow up with a brief summary of the opportunity I mentioned.

Our Epique Realty Colorado Mountain Region in Colorado's Vail Valley is uniquely positioned to serve the transatlantic luxury buyer — and we are actively seeking distinguished partners in France who share our commitment to excellence.

I would welcome the chance to speak further at your convenience. I am happy to schedule a call or meet during my upcoming visit to France.

Avec mes respectueuses salutations,
Charles Harrison | EpiVail
