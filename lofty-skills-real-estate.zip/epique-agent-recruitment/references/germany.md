# Germany — Outreach Templates & Cultural Notes

## Cultural Reminders
- Germans value precision, structure, and reliability — lead with facts, not hype
- Use formal address: "Sehr geehrte/r Herr/Frau [Last Name]" or "Dear Mr./Ms." in English
- Use professional titles if known (Dr., Prof.)
- Highlight NASDAQ listing (REAX) — institutional credibility matters
- Clear, structured commission model is a strong draw
- Avoid superlatives and vague claims — back everything with specifics
- Punctuality and follow-through are non-negotiable

---

## Cold Email — German Agent (English, Formal)
**Subject**: Partnership Opportunity — Colorado Luxury Mountain Real Estate | Epique Realty

Dear Mr. / Ms. [Last Name],

I am writing to introduce a structured partnership opportunity that may be of professional interest to you.

My name is Charles Harrison. I serve as Area Leader for Epique Realty International in Colorado's Mountain Region — a market encompassing Vail, Beaver Creek, and Aspen, with consistent transaction volumes in the $2M–$15M+ range. I have 25 years of specialized experience in luxury resort, ski-in/ski-out, and short-term rental investment properties in this corridor.

Epique Realty operates on a transparent, agent-first compensation model:
- 100% commission retention after annual cap
- Healthcare coverage included
- Lofty CRM platform included
- 12+ integrated AI tools
- Revenue share program
- Equity participation — parent company listed on NASDAQ (REAX)

I am developing an international partner network within Epique Realty Colorado Mountain Region, with a focus on agents who serve buyers with cross-market interests between Germany and North America's premier mountain resort destinations.

I will be visiting Germany this year and would welcome the opportunity to arrange a meeting at your convenience.

With kind regards,
Charles Harrison | EpiVail
Area Leader – Epique Colorado Mountain Region

---

## LinkedIn DM — German Agent
Dear [Last Name], I am Charles Harrison, Area Leader at Epique Realty in Colorado's Vail Valley. I am building an international partner network within our luxury mountain real estate division and believe your expertise in [their market] would be a strong complement. I will be in Germany later this year. Would you be open to a brief professional introduction? — Charles Harrison | EpiVail

---

## In-Person Talking Points (Germany Visit)
1. Be punctual — arrive early, never late
2. Present a business card formally with both hands
3. Open with a structured overview of who you are and why you requested the meeting
4. Present Epique's model clearly and in order — no meandering
5. Have data ready: commission structure, NASDAQ ticker, Lofty CRM feature list
6. Emphasize **reliability and long-term partnership** over short-term gains
7. Allow time for questions — Germans appreciate thoroughness
8. Close with a specific next step: "May I send you our partnership overview document?"

---

## Follow-Up (Post-Meeting or No Response)
Subject: Follow-Up: Epique Realty Colorado Mountain Partnership

Dear Mr. / Ms. [Last Name],

Thank you for your time [at our meeting / in reviewing my previous message]. As promised, I am following up with additional detail regarding the partnership opportunity with Epique Realty Colorado Mountain Region.

I have attached / can provide upon request:
- Epique Realty commission structure summary
- Epique Realty Colorado Mountain Region overview
- NASDAQ listing reference (REAX — The Real Brokerage)

I look forward to your response and remain available for a call or in-person meeting during my visit to Germany.

Mit freundlichen Grüßen,
Charles Harrison | EpiVail
Area Leader – Epique Colorado Mountain Region
