# US — Colorado Mountain Region Outreach Templates

## Cold Email — Luxury Agent
**Subject**: The Mountain Market Just Changed — Are You Positioned for It?

Hi [First Name],

I've been watching your work in [market/area] — you clearly know how to serve discerning buyers in this space. I'm Charles Harrison, Area Leader for Epique Realty in Colorado's Mountain Region, and I'm reaching out because I think you deserve a conversation about what's possible when the brokerage actually works for the agent.

At Epique, you keep 100% commission after cap — plus free healthcare, Lofty CRM, 12+ AI tools, revenue share, and real stock options on NASDAQ. No catch. No nickel-and-diming.

I've spent 25+ years in the Vail/Beaver Creek luxury resort corridor. I know what it takes to win in ski-in/ski-out, STR investment, and our Luxury Resimercial™ market. I'd love to share how Epique's model amplifies what you're already doing.

Can we grab 15 minutes this week?

Warm regards,
Charles Harrison | EpiVail
Area Leader – Epique Colorado Mountain Region
"Scale Smarter, Build Better, EpiVail"

---

## LinkedIn DM — Short Form
Hi [First Name] — love what you're building in [market]. I'm Charles Harrison, Area Leader at Epique Realty in Colorado's Mountain Region. We're growing Epique Realty Colorado Mountain Region and I think you'd be a natural fit. 100% commission after cap, free healthcare, Lofty CRM included. Worth a quick conversation? Happy to share more. — Charles

---

## In-Person Talking Points (Conference / Event)
1. Open with genuine curiosity about their market and specialty
2. Mention your 25+ years in Vail Valley — establish peer credibility
3. Ask: "Are you happy with what your brokerage keeps from your commissions?"
4. Introduce Epique: "We built a model where the agent wins first"
5. Hit the 5 pillars: 100% after cap / healthcare / Lofty CRM / AI tools / stock options
6. Close: "I'd love to send you something — what's the best way to stay in touch?"

---

## Follow-Up (5–7 Days, No Response)
Subject: Re: The Mountain Market Just Changed

Hi [First Name],

Just circling back in case my last note got buried. No pressure at all — I know how busy the market keeps us.

If there's even a small part of you that's wondered whether your brokerage is truly working for you, that conversation is worth five minutes. I've helped agents in this market keep significantly more of what they earn — while gaining tools and benefits most brokerages charge extra for.

Happy to connect whenever the timing is right.

Warm regards,
Charles Harrison | EpiVail
