# Mexico — Outreach Templates & Cultural Notes

## Cultural Reminders
- Warm, relationship-first approach — family and community resonate deeply
- Bilingual outreach preferred: open in Spanish, offer English
- Luxury resort markets (Los Cabos, Riviera Maya, Valle de Bravo) parallel Vail Valley well
- Revenue share and stock options are strong motivators — generational wealth angle
- Personal introductions and referrals carry enormous weight
- WhatsApp is a preferred professional channel in Mexico
- Don't rush — relationship must come before business

---

## Cold Email — Mexican Luxury Agent (Bilingual)
**Subject**: Una oportunidad en el mercado de lujo de montaña — Colorado, EE.UU.

Estimado/a [First Name],

Me pongo en contacto con usted porque reconozco su experiencia en el mercado inmobiliario de lujo. *(I am reaching out because I recognize your expertise in the luxury real estate market.)*

My name is Charles Harrison. I am the Area Leader for Epique Realty International in Colorado's Mountain Region — Vail, Beaver Creek, and surrounding resort communities. With 25 years in this luxury corridor, I serve buyers who are increasingly interested in both North American and Latin American resort destinations.

I am building an international partner network through Epique Realty Colorado Mountain Region, and I believe there is a meaningful bilateral opportunity between Colorado's mountain luxury market and Mexico's world-class resort destinations.

Epique Realty offers a model built for agents who want more:
- 100% commission after cap
- Free healthcare included
- Lofty CRM — no extra cost
- 12+ AI tools
- Revenue share (build lasting income beyond transactions)
- Stock options — NASDAQ listed (REAX)

I would love to connect for a conversation. ¿Podemos agendar una llamada? *(Can we schedule a call?)*

Un cordial saludo,
Charles Harrison | EpiVail
Area Leader – Epique Colorado Mountain Region
"Scale Smarter, Build Better, EpiVail"

---

## WhatsApp Message — Mexican Agent
Hola [First Name], soy Charles Harrison, Area Leader de Epique Realty en el Valle de Vail, Colorado. Estoy construyendo una red internacional de socios en bienes raíces de lujo y creo que hay una gran oportunidad para colaborar. ¿Tienes 15 minutos esta semana para platicar? — Charles 🏔️

*(Hello [First Name], I'm Charles Harrison, Area Leader at Epique Realty in Vail Valley, Colorado. I'm building an international network of luxury real estate partners and I believe there's a great collaboration opportunity. Do you have 15 minutes this week to chat?)*

---

## In-Person Talking Points (Mexico Visit / Real Estate Event)
1. Open with genuine warmth — ask about their family, their market, their story
2. Share your own story — 25 years in Vail, military veteran, community roots
3. Draw the parallel: "Your market in [Los Cabos / Riviera Maya] and our Vail Valley have the same buyer — they just summer in one and ski in the other"
4. Introduce Epique's model conversationally, not as a pitch
5. Revenue share is powerful here — frame it as building a legacy, not just a commission
6. Exchange contact info via WhatsApp — that's where the relationship lives
7. Follow up within 24 hours with a warm personal message

---

## Follow-Up (WhatsApp — Warm)
Hola [First Name], fue un placer conocerte. Como te comenté, creo que hay una conexión real entre nuestros mercados. Te mando más información sobre Epique y Epique Realty Colorado Mountain Region. ¡Hablamos pronto! — Charles 🤝

*(Hello [First Name], it was a pleasure meeting you. As I mentioned, I believe there's a real connection between our markets. I'll send you more info about Epique and Epique Realty Colorado Mountain Region. Talk soon! — Charles)*
