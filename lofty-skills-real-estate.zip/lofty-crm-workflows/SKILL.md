---
name: lofty-crm-workflows
description: Lofty CRM automation, lead routing, and workflow management for Charles Harrison's EpiVail real estate operation. Use this skill whenever Charles mentions Lofty, CRM, lead routing, lead tiers, zip code mapping, Python automation, the lofty-tools project, webhook integration, lead follow-up sequences, or pipeline management. Always activate for any request involving lead data, contact management, automated outreach sequences, CRM integrations, or the lofty-tools Python toolkit. Also trigger when building webhook endpoints that receive leads from the EpiVail agent attraction page or any Epique Realty lead sources.
---

# Lofty CRM Workflows Skill

**CRM platform**: Lofty (formerly Chime) — included free with Epique Realty membership  
**Python project**: `lofty-tools` — Charles's automation toolkit  
**Primary use**: Lead routing, tier classification, automated follow-up, pipeline visibility  
**Integration points**: EpiVail agent attraction page (webhook), Netlify (epivail.netlify.app), Claude API chatbot

---

## Lead Tier System

All inbound leads are classified into 4 tiers based on price point and engagement signals:

| Tier | Price Range | Priority | Response SLA |
|---|---|---|---|
| **Platinum** | $2.5M+ | Immediate — Charles personal outreach | < 1 hour |
| **Gold** | $1M – $2.5M | Same day | < 4 hours |
| **Silver** | $500K – $1M | Next day | < 24 hours |
| **Bronze** | < $500K | Automated nurture | 24–48 hours |

**Tier assignment logic:**
1. Check stated price range / budget in lead form
2. If no price stated: classify by zip code (see below) + property type
3. STR / investment inquiries: bump one tier up (investment intent = higher value)
4. Agent recruit leads: separate pipeline — do NOT route through buyer/seller tiers

---

## Zip Code → Tier Mapping (Eagle County, CO)

```python
ZIP_TIER_MAP = {
    # Vail Village / Lionshead — highest value
    '81657': 'Platinum',   # Vail
    '81658': 'Platinum',   # Vail (PO)
    
    # Beaver Creek / Arrowhead / Bachelor Gulch
    '81620': 'Gold',       # Avon / Beaver Creek
    '81621': 'Gold',       # Basalt (upper)
    
    # Edwards / Singletree
    '81632': 'Gold',       # Edwards
    
    # Eagle / Gypsum
    '81631': 'Silver',     # Eagle
    '81637': 'Silver',     # Gypsum
    
    # Minturn / Red Cliff
    '81645': 'Silver',     # Minturn
    
    # Default fallback
    'DEFAULT': 'Bronze',
}

def classify_lead(zip_code: str, price: float = None, is_investment: bool = False) -> str:
    if price:
        if price >= 2_500_000: tier = 'Platinum'
        elif price >= 1_000_000: tier = 'Gold'
        elif price >= 500_000: tier = 'Silver'
        else: tier = 'Bronze'
    else:
        tier = ZIP_TIER_MAP.get(zip_code, ZIP_TIER_MAP['DEFAULT'])
    
    # Bump investment leads one tier
    if is_investment:
        tiers = ['Bronze', 'Silver', 'Gold', 'Platinum']
        idx = tiers.index(tier)
        tier = tiers[min(idx + 1, 3)]
    
    return tier
```

---

## lofty-tools Project Structure

```
lofty-tools/
├── main.py              # CLI entry point
├── config.py            # API keys, webhook URLs, env vars
├── lead_router.py       # Tier classification + Lofty tag assignment
├── webhooks/
│   └── receiver.py      # Flask/FastAPI endpoint for inbound leads
├── sequences/
│   ├── platinum.py      # Platinum follow-up sequence
│   ├── gold.py          # Gold follow-up sequence
│   ├── silver.py        # Silver nurture sequence
│   └── bronze.py        # Bronze automated drip
├── utils/
│   ├── lofty_api.py     # Lofty API wrapper (contacts, tags, tasks)
│   └── notifications.py # SMS/email alerts to Charles
└── tests/
    └── test_router.py
```

---

## Lofty API Key Patterns

```python
import requests

LOFTY_API_BASE = "https://api.lofty.ai/v1"  # confirm current base URL
HEADERS = {
    "Authorization": f"Bearer {LOFTY_API_KEY}",
    "Content-Type": "application/json"
}

# Create / update contact
def upsert_contact(email, first_name, last_name, phone=None, tags=None):
    payload = {
        "email": email,
        "firstName": first_name,
        "lastName": last_name,
        "phone": phone,
        "tags": tags or []
    }
    return requests.post(f"{LOFTY_API_BASE}/contacts", json=payload, headers=HEADERS)

# Add tag to contact
def add_tag(contact_id, tag):
    return requests.post(
        f"{LOFTY_API_BASE}/contacts/{contact_id}/tags",
        json={"tag": tag},
        headers=HEADERS
    )

# Create task / follow-up reminder
def create_task(contact_id, title, due_date, assigned_to=None):
    payload = {"contactId": contact_id, "title": title, "dueDate": due_date}
    return requests.post(f"{LOFTY_API_BASE}/tasks", json=payload, headers=HEADERS)
```

---

## Webhook Receiver (EpiVail Attraction Page → Lofty)

The merged attraction page (`epivail-merged-full.html`) posts lead data to `LOFTY_WEBHOOK_URL`.

**Expected inbound payload:**
```json
{
  "firstName": "Jane",
  "lastName": "Smith",
  "email": "jane@example.com",
  "phone": "+1-555-0100",
  "market": "US",           // US | FR | DE | MX
  "language": "en",         // en | fr | de | es
  "licenseState": "CO",
  "yearsExperience": 5,
  "currentBrokerage": "RE/MAX",
  "message": "Interested in learning more about Epique",
  "source": "epivail-attraction-page"
}
```

**Processing workflow:**
1. Receive webhook POST
2. Classify lead: agent recruit → `Agent Recruit` pipeline (separate from buyer/seller)
3. Add tags: `epivail-attraction`, market tag (e.g., `market-us`), language tag
4. Create follow-up task for Charles within tier SLA
5. Trigger appropriate welcome sequence
6. Log to recruitment CRM view

---

## Agent Recruit Pipeline (Separate from Buyer/Seller)

Agent recruits from the attraction page flow into a **dedicated pipeline** — never mixed with buyer/seller leads.

**Recruit stages:**
1. `New Lead` — just came in
2. `Contacted` — Charles or team made first outreach
3. `Conversation Started` — two-way dialogue happening
4. `Presentation Sent` — EpiVail pitch deck / materials sent
5. `Decision Pending` — agent is considering
6. `Joined Epique` ✅ — conversion
7. `Not Now` — nurture for future cycle
8. `Not Interested` — remove from active sequences

**Tags used:**
- `agent-recruit`, `epivail-attraction-page`
- Market: `market-us`, `market-fr`, `market-de`, `market-mx`
- Tier (for agents): `high-producer` (100+ transactions or $10M+ GCI), `mid-producer`, `new-agent`
- Language: `lang-en`, `lang-fr`, `lang-de`, `lang-es`

---

## Follow-Up Sequence Timing

| Stage | Day 0 | Day 1 | Day 3 | Day 7 | Day 14 | Day 30 |
|---|---|---|---|---|---|---|
| Platinum | Immediate personal call | Personal email | Check-in text | Market report | Personal note | Quarterly touch |
| Gold | Same-day email | Follow-up call | Value content | Market intel | Soft ask | Monthly touch |
| Silver | Auto email | Auto follow-up | Drip content | Drip | Drip | Drip |
| Bronze | Auto drip | — | Drip | Drip | Drip | Monthly |

---

## Environment Variables

```bash
# Required in .env / Netlify environment
LOFTY_API_KEY=your_lofty_api_key
LOFTY_WEBHOOK_URL=your_webhook_endpoint
ANTHROPIC_API_KEY=your_claude_api_key  # for chatbot on attraction page

# Optional
TWILIO_ACCOUNT_SID=...   # for SMS alerts to Charles on Platinum leads
TWILIO_AUTH_TOKEN=...
CHARLES_PHONE=+1-...
```

---

## Common Tasks & Code Snippets

### Route an inbound lead end-to-end
```python
from lead_router import classify_lead
from lofty_api import upsert_contact, add_tag, create_task
from notifications import alert_charles

def process_lead(data):
    tier = classify_lead(
        zip_code=data.get('zip'),
        price=data.get('budget'),
        is_investment=data.get('propertyType') == 'investment'
    )
    contact = upsert_contact(data['email'], data['firstName'], data['lastName'])
    add_tag(contact['id'], f'tier-{tier.lower()}')
    add_tag(contact['id'], 'epivail-web')
    
    if tier == 'Platinum':
        alert_charles(f"🏔 PLATINUM LEAD: {data['firstName']} {data['lastName']} — {data['email']}")
        create_task(contact['id'], f"Personal call: {data['firstName']}", due_hours=1)
```

### Reference Files
- `references/lofty-api-endpoints.md` — Full Lofty API endpoint reference
- `references/sequence-scripts.md` — Full text of each follow-up sequence by tier
