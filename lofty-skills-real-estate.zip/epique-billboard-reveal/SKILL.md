---
name: "epique-billboard-reveal"
description: "Build an Epique digital billboard mockup for Charles Harrison from a property photo, then turn it into a Higgsfield reel where the house breaks out of the billboard and constructs itself."
---

# Epique Billboard Reveal

Two stages. Stage 1 builds the billboard artwork and mockup. Stage 2 turns that mockup into a video where the house tears off the board and rebuilds itself on the ground.

## Brand rules — do not break these

- **Never typeset or recreate the Epique logo.** Use the real EPIQUE wordmark PNG only. If it is missing, ask Charles for it or extract it from an official Epique graphic. A hand-set logo is an automatic reject.
- Name on the board is exactly `CHARLES HARRISON`. Title, when used elsewhere, is exactly "Charles Harrison, Epique Area/Growth Leader".
- Phone `(970) 904-0600`. Brokerage line is plain text, `Epique Realty`, never styled as part of the logo lockup.
- Epique palette: black `#080809`, white, coral `#F1594A`, soft grey `#C8CCD2`. Typeface: Inter Tight.
- EpiVail work is a different system: navy `#0a1628`, gold `#c9a84c`, bright gold `#e8c66a`, cream `#f5f0e8`; Cormorant Garamond / Bebas Neue / DM Sans; sign-off "Scale Smarter, Build Better… EpiVail".
- Never use "Epique Mountain Collective" or "Southern Hospitality Meets Mountain Mastery".

## Inputs needed

1. A property photo or rendering (the house).
2. A photo of a real billboard structure to mock onto.
3. Charles's cutout headshot (run `rembg` with `u2net_human_seg` if you only have a full photo).
4. The official EPIQUE wordmark as a white-on-transparent PNG.

## Stage 1 — build the board

Canvas 2800x800 (2x a 1400x400 digital bulletin), black background.

- **Left:** the house, scaled to full height, with the right edge faded into black. Build an `L` mask and ramp alpha from about 62% of the width to the right edge with a 1.4 exponent so the fade is not linear.
- **Middle:** the headshot cutout, bottom-anchored, roughly 790px tall, centered near x=1350. Put a blurred black halo behind it (Gaussian blur ~28, alpha x0.8) so the edge reads against the fade.
- **Right column** starting at x=1720, ending 110px from the right edge:
  - EPIQUE wordmark PNG at 720px wide, top at y=104.
  - Coral rule, 150x6, at y=318.
  - `CHARLES HARRISON` at y=360, Inter Tight weight 700, letter-tracked 5px, auto-fit to the column width.
  - `(970) 904-0600` at y=500, same treatment, tracking 4px.
  - `Epique Realty` at y=690, Inter Tight 40 weight 500, soft grey.

Export `-2800x800.png` and a `-1400x400.png` downscale.

**Mockup:** upscale the reference billboard photo 3x, pick the four corners of the board face (TL, TR, BR, BL), solve an 8-coefficient perspective transform mapping the output box back to the board, warp with `Image.PERSPECTIVE` and bicubic resampling, then paste through a polygon mask. Save as JPEG q92.

## Stage 2 — the Higgsfield video

### Frames

Crop both to 1920x1080 (16:9):

- **Frame 1 (start):** the billboard mockup.
- **Frame 2 (end):** the house, centered.

### Upload

`media_upload` returns a presigned S3 URL — PUT the file with curl from the sandbox, then call `media_confirm` and wait for status `uploaded`. Keep the returned media_ids.

### Model choice — check the plan first

Seedance 2.5 and 2.0 are the models this look is famous for, but Higgsfield gates **every Seedance model, and Kling's `pro` and `4k` modes, behind the Plus plan**. On a Basic account they fail with "Requires plus plan or higher" before any credits are spent, no matter how many credits are in the balance.

On Basic, use `kling3_0` with `mode: "std"`. It works and it charges credits normally. Run `get_cost: true` first to preflight.

```
model: kling3_0
mode: std
sound: off
aspect_ratio: 16:9
duration: 10          # 10s gives the build time to read; 5s is too fast
medias:
  - { value: <frame1_media_id>, role: start_image }
  - { value: <frame2_media_id>, role: end_image }
```

Render takes 6-10 minutes. Poll with `jobs_wait`, sleeping between calls.

### The prompt that works

A camera push-in is the wrong answer — it just zooms. The effect Charles wants is deconstruction into construction. Name the materials and the assembly order explicitly:

> Cinematic deconstruction and construction transformation, static wide camera at first then a slow crane move down. The flat printed house on the left side of the Epique billboard comes to life: it peels off the billboard surface and breaks apart into hundreds of 3D building pieces — wood siding planks, stacked stone blocks, black window frames, glass panes, steel beams, black metal roof panels and deck railings. The pieces fly out of the billboard and swirl down through the air in a controlled spiral, landing on the green lawn below and snapping together one by one: foundation first, then stone columns, wood-clad walls, glass windows sliding into place, the rooftop deck and railings, and finally the angled black metal roof locking on. The camera descends and pushes in as the full-size, photorealistic modern two-story home finishes assembling among green trees and landscaping in bright daylight. Satisfying mechanical assembly, realistic physics, dramatic, seamless single shot, no new text or logos.

Swap the materials to match the actual property. "No new text or logos" keeps the model from inventing signage.

## Stage 3 — check and deliver

Pull a contact sheet before sending anything:

```bash
for t in 0.5 2 3.5 5 6.5 8 9.8; do
  ffmpeg -y -v error -ss $t -i out.mp4 -frames:v 1 -vf scale=480:-2 g_$t.jpg
done
```

Look for: the board readable in the first 2 seconds, the house actually assembling rather than dissolving, and no garbled text.

Deliver two files — the original, plus a social copy under 5MB:

```bash
ffmpeg -y -i out.mp4 -c:v libx264 -preset slow -b:v 3500k -maxrate 4500k \
  -bufsize 8000k -pix_fmt yuv420p -movflags +faststart -an out-social.mp4
```

## Known rough edges, and how to fix them

- **The board goes blank.** When the house peels off, the model often clears the whole face, taking the headshot and phone number with it. Fix by making a custom last frame showing the finished house standing under the intact billboard, instead of using the bare house render.
- **The setting changes.** The house lands in whatever environment the house image carries, not under the billboard. Same fix.
- **Third-party signage.** Check the reference billboard structure for another company's name on the catwalk and blur or crop it before posting.

## Captions

Comment-and-follow only. Charles does not want "DM me" calls to action on EpiVail posts.